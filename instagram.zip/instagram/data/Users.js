const Asim=require('../assets/ProfilePics/Asim.png')
const Baby=require('../assets/ProfilePics/Baby.png')
const CopleGoals=require('../assets/ProfilePics/CoupleGoals.png')
const Mahira=require('../assets/ProfilePics/Mahira.png')
const Usman =require('../assets/ProfilePics/Usman.png')
const Bala=require('../assets/ProfilePics/Bala.png')
const Noor=require('../assets/ProfilePics/Noor.png') 

export const Users=[
  {
     user: 'm_asim',
     image:Asim
  },
  {
     user: 'noor_zafar',
     image:Noor 
  },
  {
     user: 'bala_hatun',
     image:Bala 
  },
  {
     user: 'babies',
     image:Baby
  },
  {
     user: 'couples',
     image:CopleGoals
  },
  {
     user: 'mahira_khan',
     image:Mahira
  },
  {
     user: 'kurulus_osman',
     image:Usman
  },
]