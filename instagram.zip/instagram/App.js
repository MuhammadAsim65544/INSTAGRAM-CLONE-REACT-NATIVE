import * as React from 'react';
import { View, StyleSheet, Text,TouchableOpacity,StatusBar} from 'react-native';



import Home from './screens/Home';

export default function Header() {
  return(
    <Home/> 
  )
}
