import React,{useState} from 'react';
import { View, Text,TouchableOpacity,Image} from 'react-native';

const Home=require('../../assets/icons/Home.PNG')
const Search=require('../../assets/icons/Search.PNG')
const PostCreation=require('../../assets/icons/PostCreation.png')
const Profile=require('../../assets/icons/Profile.PNG')

export const BottomTabIcons=[
  {
    name:Home
  },
  {
    name:Search
  },
  {
    name:PostCreation
  },
  {
    name:Profile
  },

]

export default BottomTabs=({icons})=>{
  const [activeTab,setActiveTab]=useState('Home')
   
  const Icon=({icon})=>{
    return(
    <View>
    <TouchableOpacity onPress={()=>setActiveTab(icon.name)}>
      <Image 
         source={icon.name}
         style={{
           width:30,
           height:30
         }}
      />
    </TouchableOpacity>
    </View>
    )
  }

  return(
    <View style={{flexDirection:'row',justifyContent:'space-around',marginBottom:5,}}>
    
      {icons.map((icon,index)=>(
        <Icon key={index} icon={icon} />
      ))}
    </View>
  )
}